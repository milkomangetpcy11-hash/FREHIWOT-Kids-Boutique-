F R E H I W O T Kids Boutique website

Files:
- index.html — complete responsive website

Before publishing:
1. Replace +251000000000 in index.html with the real call-only phone number.
2. Replace emoji placeholders with real clothing photos when available.
3. Upload index.html to Netlify or commit it to the existing GitHub repository.

No ordering/cart system is included; this version is a view-only boutique site.
